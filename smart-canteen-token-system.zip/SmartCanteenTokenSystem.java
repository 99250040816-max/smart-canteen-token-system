import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * Smart Canteen Token System
 * A complete Java Swing Desktop Application for College Canteen Queue & Token Management.
 * 
 * Features:
 * 1. Admin Authentication (Username: admin, Password: 1234)
 * 2. Food Menu selection with automatic price calculation
 * 3. FIFO Queue management using Queue<Order> and LinkedList<Order>
 * 4. JTable with custom row height and status tracking (WAITING -> PREPARING -> READY -> SERVED)
 * 5. Order state operations: Call Next, Mark Ready, Mark Served
 * 6. Full input validations and JOptionPane user alerts
 * 
 * Suitable as a 2nd-year B.Tech CSE / AIML Mini Project.
 */
public class SmartCanteenTokenSystem extends JFrame {

    // ==========================================
    // Inner Static Order Class (Requirement 8)
    // ==========================================
    public static class Order {
        int token;
        String studentName;
        String foodName;
        int quantity;
        int amount;
        String status;

        public Order(int token, String studentName, String foodName, int quantity, int amount, String status) {
            this.token = token;
            this.studentName = studentName;
            this.foodName = foodName;
            this.quantity = quantity;
            this.amount = amount;
            this.status = status;
        }

        public int getToken() { return token; }
        public String getStudentName() { return studentName; }
        public String getFoodName() { return foodName; }
        public int getQuantity() { return quantity; }
        public int getAmount() { return amount; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }

    // ==========================================
    // Class Members & Swing Components
    // ==========================================
    // Token Counter (starts from 1)
    private int tokenCounter = 1;

    // FIFO Queue Management (Requirement 7)
    private Queue<Order> orderQueue = new LinkedList<>();

    // Master list of all created orders for searching
    private List<Order> allOrders = new ArrayList<>();

    // Food Menu items (Requirement 3)
    private final String[] foodMenu = {
        "Idly - Rs.20",
        "Dosa - Rs.40",
        "Meals - Rs.70",
        "Fried Rice - Rs.80",
        "Tea - Rs.15",
        "Juice - Rs.30"
    };

    // UI Input Controls (Requirement 2 & 4)
    private JTextField txtStudentName;
    private JComboBox<String> comboFood;
    private JSpinner spinQuantity;
    private JButton btnGenerateToken;

    // Table Components (Requirement 2 & 9)
    private JTable orderTable;
    private DefaultTableModel tableModel;

    // Action Buttons (Requirement 10)
    private JButton btnCallNext;
    private JButton btnMarkReady;
    private JButton btnMarkServed;

    // Status / Queue Summary Labels
    private JLabel lblQueueCount;
    private JLabel lblNowServing;

    // ==========================================
    // Constructor: Main Window (Requirement 2)
    // ==========================================
    public SmartCanteenTokenSystem() {
        // Window Title & Configurations
        setTitle("Smart Canteen Token System");
        setSize(900, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center window on screen
        setLayout(new BorderLayout(10, 10));

        // Initialize and assemble UI panels
        initHeaderPanel();
        initCenterPanel();
        initBottomPanel();
    }

    /**
     * Top Header Banner
     */
    private void initHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(33, 50, 94));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        JLabel lblTitle = new JLabel("SMART CANTEEN TOKEN SYSTEM");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblSubtitle = new JLabel("B.Tech CSE/AIML Mini Project | Order & Queue Dispatcher");
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSubtitle.setForeground(new Color(200, 215, 245));

        JPanel titleBox = new JPanel(new GridLayout(2, 1));
        titleBox.setOpaque(false);
        titleBox.add(lblTitle);
        titleBox.add(lblSubtitle);

        headerPanel.add(titleBox, BorderLayout.WEST);

        // Queue status badge
        JPanel badgePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        badgePanel.setOpaque(false);

        lblNowServing = new JLabel("Active Queue: 0 waiting");
        lblNowServing.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblNowServing.setForeground(new Color(255, 235, 120));
        badgePanel.add(lblNowServing);

        headerPanel.add(badgePanel, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);
    }

    /**
     * Center Area: Order Entry Panel (Left) + Orders JTable (Right)
     */
    private void initCenterPanel() {
        JPanel centerPanel = new JPanel(new BorderLayout(15, 15));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        // -----------------------------------------------------------------
        // LEFT: Order Entry Panel (Requirement 4)
        // -----------------------------------------------------------------
        JPanel entryPanel = new JPanel();
        entryPanel.setLayout(new BoxLayout(entryPanel, BoxLayout.Y_AXIS));
        entryPanel.setPreferredSize(new Dimension(320, 400));
        entryPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(180, 195, 220), 1),
                " Place New Order ",
                0, 0,
                new Font("Segoe UI", Font.BOLD, 14),
                new Color(33, 50, 94)
            ),
            BorderFactory.createEmptyBorder(12, 12, 12, 12)
        ));

        // Field 1: Student Name
        JLabel lblName = new JLabel("Student Name:");
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblName.setAlignmentX(Component.LEFT_ALIGNMENT);

        txtStudentName = new JTextField();
        txtStudentName.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtStudentName.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        txtStudentName.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Field 2: Food Menu (Requirement 3)
        JLabel lblFood = new JLabel("Food Item:");
        lblFood.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblFood.setAlignmentX(Component.LEFT_ALIGNMENT);

        comboFood = new JComboBox<>(foodMenu);
        comboFood.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        comboFood.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        comboFood.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Field 3: Quantity Spinner (Requirement 4 - min:1, max:20, default:1)
        JLabel lblQty = new JLabel("Quantity (1 - 20):");
        lblQty.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblQty.setAlignmentX(Component.LEFT_ALIGNMENT);

        SpinnerNumberModel spinnerModel = new SpinnerNumberModel(1, 1, 20, 1);
        spinQuantity = new JSpinner(spinnerModel);
        spinQuantity.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        spinQuantity.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        spinQuantity.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Live estimated price label
        final JLabel lblEstimatedAmount = new JLabel("Estimated Amount: Rs.20");
        lblEstimatedAmount.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lblEstimatedAmount.setForeground(new Color(80, 90, 110));
        lblEstimatedAmount.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Update estimate listener
        ActionListener updateEstimate = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedItem = (String) comboFood.getSelectedItem();
                int price = extractPrice(selectedItem);
                int qty = (int) spinQuantity.getValue();
                lblEstimatedAmount.setText("Estimated Amount: Rs." + (price * qty));
            }
        };
        comboFood.addActionListener(updateEstimate);
        spinQuantity.addChangeListener(e -> updateEstimate.actionPerformed(null));

        // Button: Generate Token (Requirement 4 & 5)
        btnGenerateToken = new JButton("Generate Token");
        btnGenerateToken.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnGenerateToken.setBackground(new Color(24, 134, 75));
        btnGenerateToken.setForeground(Color.WHITE);
        btnGenerateToken.setFocusPainted(false);
        btnGenerateToken.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        btnGenerateToken.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnGenerateToken.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnGenerateToken.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleGenerateToken();
            }
        });

        // Add components with spacing
        entryPanel.add(lblName);
        entryPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        entryPanel.add(txtStudentName);
        entryPanel.add(Box.createRigidArea(new Dimension(0, 12)));

        entryPanel.add(lblFood);
        entryPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        entryPanel.add(comboFood);
        entryPanel.add(Box.createRigidArea(new Dimension(0, 12)));

        entryPanel.add(lblQty);
        entryPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        entryPanel.add(spinQuantity);
        entryPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        entryPanel.add(lblEstimatedAmount);
        entryPanel.add(Box.createRigidArea(new Dimension(0, 18)));

        entryPanel.add(btnGenerateToken);
        entryPanel.add(Box.createVerticalGlue());

        centerPanel.add(entryPanel, BorderLayout.WEST);

        // -----------------------------------------------------------------
        // RIGHT: Orders JTable (Requirement 9)
        // -----------------------------------------------------------------
        String[] columnNames = {"Token", "Student", "Food", "Quantity", "Amount", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            // Make cells non-editable directly
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        orderTable = new JTable(tableModel);
        orderTable.setRowHeight(28); // Requirement 9: approximately 28 pixels
        orderTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        orderTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        orderTable.getTableHeader().setBackground(new Color(230, 238, 250));
        orderTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        orderTable.setGridColor(new Color(225, 230, 240));

        // Center align token, quantity, amount, status
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        orderTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        orderTable.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        orderTable.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
        orderTable.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);

        // Column widths
        orderTable.getColumnModel().getColumn(0).setPreferredWidth(60);
        orderTable.getColumnModel().getColumn(1).setPreferredWidth(140);
        orderTable.getColumnModel().getColumn(2).setPreferredWidth(120);
        orderTable.getColumnModel().getColumn(3).setPreferredWidth(70);
        orderTable.getColumnModel().getColumn(4).setPreferredWidth(80);
        orderTable.getColumnModel().getColumn(5).setPreferredWidth(110);

        JScrollPane scrollPane = new JScrollPane(orderTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(180, 195, 220), 1),
            " Active Orders Board ",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(33, 50, 94)
        ));

        centerPanel.add(scrollPane, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);
    }

    /**
     * Bottom Action Bar: Call Next, Mark Ready, Mark Served (Requirement 10)
     */
    private void initBottomPanel() {
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 12));
        bottomPanel.setBackground(new Color(245, 248, 252));
        bottomPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(210, 220, 235)));

        // Call Next Button (Requirement 11)
        btnCallNext = new JButton("Call Next");
        btnCallNext.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnCallNext.setBackground(new Color(30, 100, 200));
        btnCallNext.setForeground(Color.WHITE);
        btnCallNext.setFocusPainted(false);
        btnCallNext.setPreferredSize(new Dimension(130, 36));
        btnCallNext.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnCallNext.addActionListener(e -> handleCallNext());

        // Mark Ready Button (Requirement 12)
        btnMarkReady = new JButton("Mark Ready");
        btnMarkReady.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnMarkReady.setBackground(new Color(220, 130, 0));
        btnMarkReady.setForeground(Color.WHITE);
        btnMarkReady.setFocusPainted(false);
        btnMarkReady.setPreferredSize(new Dimension(130, 36));
        btnMarkReady.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnMarkReady.addActionListener(e -> handleMarkReady());

        // Mark Served Button (Requirement 13)
        btnMarkServed = new JButton("Mark Served");
        btnMarkServed.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnMarkServed.setBackground(new Color(40, 150, 90));
        btnMarkServed.setForeground(Color.WHITE);
        btnMarkServed.setFocusPainted(false);
        btnMarkServed.setPreferredSize(new Dimension(130, 36));
        btnMarkServed.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnMarkServed.addActionListener(e -> handleMarkServed());

        bottomPanel.add(btnCallNext);
        bottomPanel.add(btnMarkReady);
        bottomPanel.add(btnMarkServed);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    // =========================================================================
    // Core Business Logic & Handlers
    // =========================================================================

    /**
     * Requirement 4, 5 & 6: Validate inputs, generate token, calculate amount,
     * add to queue, and update JTable.
     */
    private void handleGenerateToken() {
        String name = txtStudentName.getText().trim();
        String selectedFoodItem = (String) comboFood.getSelectedItem();
        int quantity;

        // Validation 1: Student name cannot be empty (Requirement 14)
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Student name cannot be empty!", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            txtStudentName.requestFocus();
            return;
        }

        // Validation 2: Food must be selected (Requirement 14)
        if (selectedFoodItem == null || selectedFoodItem.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please select a food item.", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validation 3: Quantity between 1 and 20 (Requirement 14)
        try {
            quantity = (int) spinQuantity.getValue();
            if (quantity < 1 || quantity > 20) {
                JOptionPane.showMessageDialog(this, 
                    "Quantity must be between 1 and 20.", 
                    "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Invalid quantity value.", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Extract food name and price (Requirement 6)
        String foodName = extractFoodName(selectedFoodItem);
        int price = extractPrice(selectedFoodItem);
        int totalAmount = price * quantity; // Total Amount = Food Price × Quantity

        // Assign token and increment (Requirement 5)
        int currentToken = tokenCounter++;

        // Default status is WAITING (Requirement 10)
        Order newOrder = new Order(currentToken, name, foodName, quantity, totalAmount, "WAITING");

        // Add to FIFO Queue (Requirement 7: orderQueue.offer(order))
        orderQueue.offer(newOrder);
        allOrders.add(newOrder);

        // Add row to JTable (Requirement 6: Amount formatted as "Rs.X")
        tableModel.addRow(new Object[]{
            newOrder.token,
            newOrder.studentName,
            newOrder.foodName,
            newOrder.quantity,
            "Rs." + newOrder.amount,
            newOrder.status
        });

        // Display Success Message (Requirement 5)
        JOptionPane.showMessageDialog(this, 
            "Order placed successfully!\nYour Token Number: " + currentToken, 
            "Order Confirmation", 
            JOptionPane.INFORMATION_MESSAGE);

        // Reset input fields
        txtStudentName.setText("");
        comboFood.setSelectedIndex(0);
        spinQuantity.setValue(1);
        updateQueueLabel();
    }

    /**
     * Requirement 11: Call Next Order
     * Uses FIFO orderQueue.peek() to get the head order.
     */
    private void handleCallNext() {
        // Check whether the queue is empty
        if (orderQueue.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "No waiting orders.", 
                "Queue Status", 
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Get the first order using peek()
        Order nextOrder = orderQueue.peek();

        // Change status to PREPARING
        nextOrder.setStatus("PREPARING");

        // Update JTable
        updateTable(nextOrder);

        // Display notification
        JOptionPane.showMessageDialog(this, 
            "Now Preparing Token: " + nextOrder.token, 
            "Kitchen Update", 
            JOptionPane.INFORMATION_MESSAGE);

        updateQueueLabel();
    }

    /**
     * Requirement 12: Mark Selected Order as READY
     */
    private void handleMarkReady() {
        int selectedRow = orderTable.getSelectedRow();

        // Check whether an order is selected
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select an order.", 
                "Selection Required", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        int token = (int) tableModel.getValueAt(selectedRow, 0);
        Order order = findOrder(token);

        if (order != null) {
            // Change its status to READY
            order.setStatus("READY");

            // Update the table
            updateTable(order);

            // Display message
            JOptionPane.showMessageDialog(this, 
                "Token " + order.token + " is READY!", 
                "Order Ready", 
                JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Requirement 13: Mark Selected Order as SERVED
     * If that order is at the front of the queue, remove it using orderQueue.poll().
     */
    private void handleMarkServed() {
        int selectedRow = orderTable.getSelectedRow();

        // Check whether an order is selected
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select an order.", 
                "Selection Required", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        int token = (int) tableModel.getValueAt(selectedRow, 0);
        Order order = findOrder(token);

        if (order != null) {
            // Change status to SERVED
            order.setStatus("SERVED");

            // Update the table
            updateTable(order);

            // If that order is at the front of the queue, remove it using poll()
            if (!orderQueue.isEmpty() && orderQueue.peek().token == order.token) {
                orderQueue.poll();
            } else {
                // If served out of strict sequence from the table, remove from queue
                orderQueue.remove(order);
            }

            // Display message
            JOptionPane.showMessageDialog(this, 
                "Token " + order.token + " has been SERVED.", 
                "Order Completed", 
                JOptionPane.INFORMATION_MESSAGE);

            updateQueueLabel();
        }
    }

    // =========================================================================
    // Helper Methods (Requirement 15)
    // =========================================================================

    /**
     * Search for an order by its unique token number.
     */
    public Order findOrder(int token) {
        for (Order ord : allOrders) {
            if (ord.token == token) {
                return ord;
            }
        }
        return null;
    }

    /**
     * Update the status of the corresponding row in the JTable.
     */
    public void updateTable(Order order) {
        if (order == null) return;

        for (int r = 0; r < tableModel.getRowCount(); r++) {
            int rowToken = (int) tableModel.getValueAt(r, 0);
            if (rowToken == order.token) {
                tableModel.setValueAt(order.status, r, 5);
                break;
            }
        }
    }

    /**
     * Helper to extract price from menu string (e.g. "Dosa - Rs.40" -> 40)
     */
    private int extractPrice(String menuItem) {
        try {
            if (menuItem != null && menuItem.contains("Rs.")) {
                String pricePart = menuItem.substring(menuItem.indexOf("Rs.") + 3).trim();
                return Integer.parseInt(pricePart);
            }
        } catch (NumberFormatException e) {
            // Fallback
        }
        return 0;
    }

    /**
     * Helper to extract food name from menu string (e.g. "Dosa - Rs.40" -> "Dosa")
     */
    private String extractFoodName(String menuItem) {
        if (menuItem != null && menuItem.contains(" - ")) {
            return menuItem.substring(0, menuItem.indexOf(" - ")).trim();
        }
        return menuItem != null ? menuItem : "";
    }

    /**
     * Updates queue count badge
     */
    private void updateQueueLabel() {
        int count = orderQueue.size();
        lblNowServing.setText("Active Queue: " + count + " waiting");
    }

    // =========================================================================
    // Login Dialog (Requirement 1)
    // =========================================================================
    public static void showLoginDialog() {
        final JFrame loginFrame = new JFrame("SMART CANTEEN LOGIN");
        loginFrame.setSize(380, 260);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setLocationRelativeTo(null); // Center on screen
        loginFrame.setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(245, 248, 252));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Title Header
        JLabel lblHeader = new JLabel("SMART CANTEEN LOGIN", SwingConstants.CENTER);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblHeader.setForeground(new Color(33, 50, 94));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(lblHeader, gbc);

        JLabel lblSub = new JLabel("Default: admin / 1234", SwingConstants.CENTER);
        lblSub.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblSub.setForeground(Color.GRAY);
        gbc.gridy = 1;
        panel.add(lblSub, gbc);

        // Username Field
        gbc.gridwidth = 1;
        gbc.gridy = 2;
        gbc.gridx = 0;
        JLabel lblUser = new JLabel("Username:");
        lblUser.setFont(new Font("Segoe UI", Font.BOLD, 13));
        panel.add(lblUser, gbc);

        gbc.gridx = 1;
        JTextField txtUsername = new JTextField(12);
        txtUsername.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        panel.add(txtUsername, gbc);

        // Password Field (JPasswordField)
        gbc.gridy = 3;
        gbc.gridx = 0;
        JLabel lblPass = new JLabel("Password:");
        lblPass.setFont(new Font("Segoe UI", Font.BOLD, 13));
        panel.add(lblPass, gbc);

        gbc.gridx = 1;
        JPasswordField txtPassword = new JPasswordField(12);
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        panel.add(txtPassword, gbc);

        // LOGIN Button
        gbc.gridy = 4;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        JButton btnLogin = new JButton("LOGIN");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnLogin.setBackground(new Color(33, 50, 94));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogin.setPreferredSize(new Dimension(100, 34));
        panel.add(btnLogin, gbc);

        // Action Listener for Login
        ActionListener loginAction = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = txtUsername.getText().trim();
                String password = new String(txtPassword.getPassword());

                // Credentials check (Requirement 1: admin / 1234)
                if ("admin".equals(username) && "1234".equals(password)) {
                    // Close login window
                    loginFrame.dispose();

                    // Open Smart Canteen Token System dashboard
                    SmartCanteenTokenSystem app = new SmartCanteenTokenSystem();
                    app.setVisible(true);
                } else {
                    // Display: "Invalid Username or Password!"
                    JOptionPane.showMessageDialog(loginFrame, 
                        "Invalid Username or Password!", 
                        "Login Error", 
                        JOptionPane.ERROR_MESSAGE);
                    txtPassword.setText("");
                    txtPassword.requestFocus();
                }
            }
        };

        btnLogin.addActionListener(loginAction);
        txtPassword.addActionListener(loginAction);

        loginFrame.add(panel);
        loginFrame.setVisible(true);
    }

    // =========================================================================
    // Program Main Method (Requirement 17)
    // =========================================================================
    public static void main(String[] args) {
        // Set Look and Feel to System Look and Feel if available
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }

        // Swing thread execution
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                showLoginDialog();
            }
        });
    }
}
