export type OrderStatus = 'WAITING' | 'PREPARING' | 'READY' | 'SERVED';

export interface Order {
  token: number;
  studentName: string;
  foodName: string;
  quantity: number;
  amount: number;
  status: OrderStatus;
  timestamp: string;
}

export interface MenuItem {
  fullName: string;
  name: string;
  price: number;
}

export interface JOptionPaneAlert {
  title: string;
  message: string;
  type: 'INFO' | 'ERROR' | 'WARNING';
}
