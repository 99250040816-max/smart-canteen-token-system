import React, { useState } from 'react';
import { Order, OrderStatus } from '../types';
import { 
  Coffee, 
  UtensilsCrossed, 
  UserCheck, 
  Clock, 
  CheckCircle2, 
  Flame, 
  ArrowRight, 
  LogOut, 
  Plus, 
  Minus,
  Sparkles,
  Layers,
  ChevronRight
} from 'lucide-react';

interface Props {
  onLogout: () => void;
  showSwingAlert: (title: string, message: string, type?: 'INFO' | 'ERROR' | 'WARNING') => void;
}

const FOOD_MENU = [
  'Idly - Rs.20',
  'Dosa - Rs.40',
  'Meals - Rs.70',
  'Fried Rice - Rs.80',
  'Tea - Rs.15',
  'Juice - Rs.30',
];

const extractPrice = (menuItem: string): number => {
  if (menuItem.includes('Rs.')) {
    const part = menuItem.split('Rs.')[1].trim();
    return parseInt(part, 10) || 0;
  }
  return 0;
};

const extractFoodName = (menuItem: string): string => {
  if (menuItem.includes(' - ')) {
    return menuItem.split(' - ')[0].trim();
  }
  return menuItem;
};

export const CanteenDashboard: React.FC<Props> = ({ onLogout, showSwingAlert }) => {
  // State variables matching Java variables
  const [tokenCounter, setTokenCounter] = useState<number>(1);
  const [studentName, setStudentName] = useState<string>('');
  const [selectedFood, setSelectedFood] = useState<string>(FOOD_MENU[0]);
  const [quantity, setQuantity] = useState<number>(1);

  // Active FIFO Queue (LinkedList<Order>)
  const [orderQueue, setOrderQueue] = useState<Order[]>([]);

  // Master list of all orders (all rows in JTable)
  const [allOrders, setAllOrders] = useState<Order[]>([]);

  // Selected row token in JTable
  const [selectedToken, setSelectedToken] = useState<number | null>(null);

  // Quick sample generator for 2nd year project demonstration
  const handleQuickSeed = () => {
    const sampleStudents = ['Rahul Sharma', 'Ananya Reddy', 'Karthik V.', 'Pooja Nair', 'Siddharth M.'];
    const sampleFoods = [FOOD_MENU[1], FOOD_MENU[0], FOOD_MENU[3], FOOD_MENU[2], FOOD_MENU[4]];
    const sampleQtys = [2, 1, 1, 2, 3];

    let current = tokenCounter;
    const newOrders: Order[] = [];

    for (let i = 0; i < 3; i++) {
      const foodItem = sampleFoods[i];
      const fname = extractFoodName(foodItem);
      const price = extractPrice(foodItem);
      const qty = sampleQtys[i];
      const ord: Order = {
        token: current++,
        studentName: sampleStudents[i],
        foodName: fname,
        quantity: qty,
        amount: price * qty,
        status: i === 0 ? 'PREPARING' : 'WAITING',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      newOrders.push(ord);
    }

    setTokenCounter(current);
    setAllOrders(prev => [...prev, ...newOrders]);
    setOrderQueue(prev => [...prev, ...newOrders]);
    showSwingAlert('Demo Orders Loaded', 'Sample student orders populated into FIFO Queue & JTable!', 'INFO');
  };

  // Helper method: findOrder(int token)
  const findOrder = (token: number): Order | undefined => {
    return allOrders.find(o => o.token === token);
  };

  // Helper method: updateTable(Order order)
  const updateTable = (updatedOrder: Order) => {
    setAllOrders(prev => prev.map(o => o.token === updatedOrder.token ? updatedOrder : o));
    setOrderQueue(prev => prev.map(o => o.token === updatedOrder.token ? updatedOrder : o));
  };

  // Calculate live amount for the selected combo and spinner
  const currentPrice = extractPrice(selectedFood);
  const currentTotal = currentPrice * quantity;

  // Requirement 4 & 5: Generate Token
  const handleGenerateToken = (e: React.FormEvent) => {
    e.preventDefault();

    // Validation 1: Student name cannot be empty
    const trimmedName = studentName.trim();
    if (!trimmedName) {
      showSwingAlert('Validation Error', 'Student name cannot be empty!', 'ERROR');
      return;
    }

    // Validation 2: Food must be selected
    if (!selectedFood) {
      showSwingAlert('Validation Error', 'Please select a food item.', 'ERROR');
      return;
    }

    // Validation 3: Quantity must be between 1 and 20
    if (quantity < 1 || quantity > 20) {
      showSwingAlert('Validation Error', 'Quantity must be between 1 and 20.', 'ERROR');
      return;
    }

    const foodName = extractFoodName(selectedFood);
    const amount = currentPrice * quantity;
    const newToken = tokenCounter;

    // Create new Order object with initial status "WAITING"
    const newOrder: Order = {
      token: newToken,
      studentName: trimmedName,
      foodName: foodName,
      quantity: quantity,
      amount: amount,
      status: 'WAITING',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    // Increment token number automatically
    setTokenCounter(prev => prev + 1);

    // FIFO Queue: orderQueue.offer(order)
    setOrderQueue(prev => [...prev, newOrder]);

    // Table: tableModel.addRow(...)
    setAllOrders(prev => [...prev, newOrder]);

    // Reset inputs
    setStudentName('');
    setSelectedFood(FOOD_MENU[0]);
    setQuantity(1);

    // JOptionPane message (Requirement 5)
    showSwingAlert(
      'Order Confirmation',
      `Order placed successfully!\nYour Token Number: ${newToken}`,
      'INFO'
    );
  };

  // Requirement 11: Call Next
  const handleCallNext = () => {
    // Check whether the queue is empty
    if (orderQueue.length === 0) {
      showSwingAlert('Queue Status', 'No waiting orders.', 'INFO');
      return;
    }

    // Get the first order using peek()
    const headOrder = orderQueue[0];

    // Change status to PREPARING
    const updatedOrder: Order = {
      ...headOrder,
      status: 'PREPARING'
    };

    // Update JTable
    updateTable(updatedOrder);

    // Display: “Now Preparing Token: X”
    showSwingAlert(
      'Kitchen Update',
      `Now Preparing Token: ${updatedOrder.token}`,
      'INFO'
    );
  };

  // Requirement 12: Mark Ready
  const handleMarkReady = () => {
    if (selectedToken === null) {
      showSwingAlert('Selection Required', 'Please select an order.', 'WARNING');
      return;
    }

    const order = findOrder(selectedToken);
    if (!order) {
      showSwingAlert('Error', 'Selected order not found.', 'ERROR');
      return;
    }

    // Change its status to: READY
    const updatedOrder: Order = {
      ...order,
      status: 'READY'
    };

    // Update table
    updateTable(updatedOrder);

    // Display: “Token X is READY!”
    showSwingAlert(
      'Order Ready',
      `Token ${order.token} is READY!`,
      'INFO'
    );
  };

  // Requirement 13: Mark Served
  const handleMarkServed = () => {
    if (selectedToken === null) {
      showSwingAlert('Selection Required', 'Please select an order.', 'WARNING');
      return;
    }

    const order = findOrder(selectedToken);
    if (!order) {
      showSwingAlert('Error', 'Selected order not found.', 'ERROR');
      return;
    }

    // Change status to: SERVED
    const updatedOrder: Order = {
      ...order,
      status: 'SERVED'
    };

    // Update table
    updateTable(updatedOrder);

    // If that order is at the front of the queue, remove it using: orderQueue.poll();
    setOrderQueue(prevQueue => {
      if (prevQueue.length > 0 && prevQueue[0].token === order.token) {
        return prevQueue.slice(1); // poll head
      }
      // If served by specific selection, remove from active queue
      return prevQueue.filter(o => o.token !== order.token);
    });

    // Display: “Token X has been SERVED.”
    showSwingAlert(
      'Order Completed',
      `Token ${order.token} has been SERVED.`,
      'INFO'
    );
  };

  // Get status badge styling
  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'WAITING':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-300">
            <Clock className="w-3 h-3 mr-1 text-amber-600" />
            WAITING
          </span>
        );
      case 'PREPARING':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-100 text-blue-800 border border-blue-300 animate-pulse">
            <Flame className="w-3 h-3 mr-1 text-blue-600" />
            PREPARING
          </span>
        );
      case 'READY':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-orange-100 text-orange-800 border border-orange-300">
            <Sparkles className="w-3 h-3 mr-1 text-orange-600" />
            READY
          </span>
        );
      case 'SERVED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3 h-3 mr-1 text-emerald-600" />
            SERVED
          </span>
        );
    }
  };

  return (
    <div 
      className="w-full max-w-[960px] mx-auto bg-[#F4F6F9] border border-neutral-300 rounded-lg shadow-2xl overflow-hidden font-sans flex flex-col"
      id="swing-mainframe-container"
      style={{ minHeight: '550px' }}
    >
      {/* ------------------------------------------------------------- */}
      {/* Swing JFrame Window Bar (Title: Smart Canteen Token System)    */}
      {/* ------------------------------------------------------------- */}
      <div className="bg-[#21325E] text-white px-4 py-2 flex items-center justify-between select-none border-b border-blue-950">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full bg-amber-400 flex items-center justify-center text-[8px] font-bold text-neutral-900">
            C
          </div>
          <span className="text-xs font-bold tracking-wide">Smart Canteen Token System [JFrame ~ 900 × 550]</span>
        </div>
        <div className="flex items-center space-x-3 text-xs">
          <button
            onClick={handleQuickSeed}
            className="hidden sm:inline-flex items-center gap-1 text-[11px] bg-blue-900/60 hover:bg-blue-800 text-blue-200 px-2 py-0.5 rounded border border-blue-700/50 transition cursor-pointer"
            id="seed-demo-orders-btn"
            title="Populate test orders into FIFO Queue"
          >
            <Plus className="w-3 h-3" /> Sample Orders
          </button>
          <button
            onClick={onLogout}
            className="inline-flex items-center gap-1 text-[11px] bg-red-900/50 hover:bg-red-800 text-red-100 px-2 py-0.5 rounded border border-red-700/50 transition cursor-pointer"
            id="logout-btn"
            title="Return to Login Frame"
          >
            <LogOut className="w-3 h-3" /> Logout
          </button>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* Header Banner (Requirement 2)                                 */}
      {/* ------------------------------------------------------------- */}
      <div className="bg-gradient-to-r from-[#1B294D] via-[#21325E] to-[#2D427B] text-white px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-sm">
        <div>
          <div className="flex items-center space-x-2">
            <Coffee className="w-5 h-5 text-amber-400" />
            <h1 className="text-lg sm:text-xl font-black tracking-wide text-white">
              SMART CANTEEN TOKEN SYSTEM
            </h1>
          </div>
          <p className="text-xs text-blue-200 mt-0.5">
            2nd-Year B.Tech CSE/AIML Mini Project | Java Swing &amp; FIFO Queue (<span className="font-mono text-amber-300">LinkedList&lt;Order&gt;</span>)
          </p>
        </div>

        {/* Active Queue Status Badge */}
        <div className="flex items-center space-x-3 self-start sm:self-auto">
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded px-3 py-1.5 flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <div className="text-right">
              <div className="text-[10px] uppercase font-semibold text-blue-200">Active FIFO Queue</div>
              <div className="text-xs font-bold text-amber-300">
                {orderQueue.length} order{orderQueue.length === 1 ? '' : 's'} waiting
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* Main Content Area: Left (Place Order) + Right (JTable)        */}
      {/* ------------------------------------------------------------- */}
      <div className="p-4 sm:p-5 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-5 bg-[#F8FAFC]">
        {/* Left Column: Place New Order Panel (JPanel titled border) */}
        <div className="lg:col-span-4 flex flex-col">
          <div 
            className="bg-white border border-neutral-300 rounded-md p-4 shadow-sm flex flex-col h-full"
            id="order-entry-panel"
          >
            <div className="border-b border-neutral-200 pb-2 mb-4 flex items-center justify-between">
              <div className="flex items-center space-x-1.5 text-xs font-bold text-[#21325E] uppercase tracking-wider">
                <UtensilsCrossed className="w-3.5 h-3.5 text-blue-700" />
                <span>Place New Order</span>
              </div>
              <span className="text-[11px] font-mono text-neutral-500 bg-neutral-100 px-1.5 py-0.5 rounded">
                Token Next: #{tokenCounter}
              </span>
            </div>

            <form onSubmit={handleGenerateToken} className="space-y-3.5 flex-1 flex flex-col justify-between">
              <div className="space-y-3.5">
                {/* Field 1: Student Name (JTextField) */}
                <div>
                  <label 
                    htmlFor="student-name-input"
                    className="block text-xs font-bold text-neutral-700 mb-1"
                  >
                    Student Name: <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="student-name-input"
                    type="text"
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    placeholder="e.g. S. Keerthi"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-[#21325E] focus:border-[#21325E] transition"
                  />
                </div>

                {/* Field 2: Food Menu (JComboBox) */}
                <div>
                  <label 
                    htmlFor="food-combo-box"
                    className="block text-xs font-bold text-neutral-700 mb-1"
                  >
                    Food: <span className="text-[10px] font-normal text-neutral-500">(JComboBox)</span>
                  </label>
                  <select
                    id="food-combo-box"
                    value={selectedFood}
                    onChange={(e) => setSelectedFood(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-[#21325E] focus:border-[#21325E] transition font-medium"
                  >
                    {FOOD_MENU.map((item, idx) => (
                      <option key={idx} value={item}>{item}</option>
                    ))}
                  </select>
                </div>

                {/* Field 3: Quantity (JSpinner: min=1, max=20, default=1) */}
                <div>
                  <label 
                    htmlFor="quantity-spinner"
                    className="block text-xs font-bold text-neutral-700 mb-1 flex items-center justify-between"
                  >
                    <span>Quantity: <span className="text-[10px] font-normal text-neutral-500">(1 - 20, JSpinner)</span></span>
                    <span className="text-[11px] text-blue-700 font-semibold font-mono">
                      @ Rs.{currentPrice} each
                    </span>
                  </label>
                  <div className="flex items-center space-x-1">
                    <button
                      type="button"
                      onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
                      disabled={quantity <= 1}
                      className="p-1.5 bg-neutral-100 hover:bg-neutral-200 border border-neutral-300 rounded text-neutral-700 disabled:opacity-40 transition cursor-pointer"
                      id="spinner-decrement"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <input
                      id="quantity-spinner"
                      type="number"
                      min={1}
                      max={20}
                      value={quantity}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10);
                        if (!isNaN(val)) {
                          setQuantity(Math.min(20, Math.max(1, val)));
                        }
                      }}
                      className="flex-1 text-center py-1.5 text-xs font-bold border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-[#21325E]"
                    />
                    <button
                      type="button"
                      onClick={() => setQuantity(prev => Math.min(20, prev + 1))}
                      disabled={quantity >= 20}
                      className="p-1.5 bg-neutral-100 hover:bg-neutral-200 border border-neutral-300 rounded text-neutral-700 disabled:opacity-40 transition cursor-pointer"
                      id="spinner-increment"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Live Amount Calculation Display (Requirement 6) */}
                <div className="bg-blue-50/70 border border-blue-200 rounded p-2.5 text-xs text-neutral-700">
                  <div className="flex justify-between items-center">
                    <span className="text-neutral-500">Selected Item:</span>
                    <span className="font-semibold">{extractFoodName(selectedFood)}</span>
                  </div>
                  <div className="flex justify-between items-center mt-1">
                    <span className="text-neutral-500">Rate × Qty:</span>
                    <span className="font-mono">Rs.{currentPrice} × {quantity}</span>
                  </div>
                  <div className="border-t border-blue-200 mt-1.5 pt-1.5 flex justify-between items-center text-sm font-bold text-[#21325E]">
                    <span>Total Amount:</span>
                    <span className="text-base text-blue-900 font-mono">Rs.{currentTotal}</span>
                  </div>
                </div>
              </div>

              {/* Generate Token Button (Requirement 4) */}
              <div className="pt-2">
                <button
                  type="submit"
                  id="btn-generate-token"
                  className="w-full py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white text-xs font-bold rounded shadow-sm transition cursor-pointer flex items-center justify-center space-x-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>Generate Token</span>
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Right Column: JTable Board (Requirement 9) */}
        <div className="lg:col-span-8 flex flex-col">
          <div 
            className="bg-white border border-neutral-300 rounded-md p-4 shadow-sm flex flex-col h-full"
            id="orders-table-panel"
          >
            <div className="border-b border-neutral-200 pb-2 mb-3 flex items-center justify-between">
              <div className="flex items-center space-x-1.5 text-xs font-bold text-[#21325E] uppercase tracking-wider">
                <Layers className="w-3.5 h-3.5 text-blue-700" />
                <span>Orders Table (JTable | DefaultTableModel)</span>
              </div>
              <span className="text-[11px] text-neutral-500">
                Row Height: <span className="font-mono font-semibold">28px</span> | Click row to select
              </span>
            </div>

            {/* JTable inside JScrollPane (Requirement 9) */}
            <div className="flex-1 overflow-x-auto overflow-y-auto max-h-[300px] border border-neutral-200 rounded">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#E9EEF4] text-neutral-700 font-bold border-b border-neutral-300 select-none sticky top-0 z-10">
                    <th className="py-2 px-3 text-center border-r border-neutral-300 w-16">Token</th>
                    <th className="py-2 px-3 border-r border-neutral-300">Student</th>
                    <th className="py-2 px-3 border-r border-neutral-300">Food</th>
                    <th className="py-2 px-3 text-center border-r border-neutral-300 w-16">Quantity</th>
                    <th className="py-2 px-3 text-center border-r border-neutral-300 w-24">Amount</th>
                    <th className="py-2 px-3 text-center w-28">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200">
                  {allOrders.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-neutral-400 font-medium italic">
                        No orders in the system. Use "Place New Order" or "Sample Orders" to start.
                      </td>
                    </tr>
                  ) : (
                    allOrders.map((order) => {
                      const isSelected = selectedToken === order.token;
                      return (
                        <tr
                          key={order.token}
                          onClick={() => setSelectedToken(order.token)}
                          className={`cursor-pointer transition-colors select-none ${
                            isSelected 
                              ? 'bg-blue-100 font-medium' 
                              : 'hover:bg-neutral-50 bg-white'
                          }`}
                          style={{ height: '28px' }} // Requirement 9: row height ~28px
                        >
                          <td className="py-1 px-3 text-center font-bold font-mono text-[#21325E] border-r border-neutral-200">
                            #{order.token}
                          </td>
                          <td className="py-1 px-3 text-neutral-800 border-r border-neutral-200 truncate max-w-[140px]">
                            {order.studentName}
                          </td>
                          <td className="py-1 px-3 text-neutral-700 border-r border-neutral-200">
                            {order.foodName}
                          </td>
                          <td className="py-1 px-3 text-center text-neutral-700 font-mono border-r border-neutral-200">
                            {order.quantity}
                          </td>
                          <td className="py-1 px-3 text-center font-mono font-semibold text-neutral-800 border-r border-neutral-200">
                            Rs.{order.amount}
                          </td>
                          <td className="py-1 px-3 text-center">
                            {getStatusBadge(order.status)}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Selection status helper */}
            <div className="mt-2 text-[11px] text-neutral-500 flex items-center justify-between">
              <span>
                {selectedToken !== null ? (
                  <span className="text-blue-700 font-medium">
                    Selected Order: <span className="font-mono font-bold">Token #{selectedToken}</span> ({findOrder(selectedToken)?.studentName})
                  </span>
                ) : (
                  <span>Select any table row to perform "Mark Ready" or "Mark Served"</span>
                )}
              </span>
              <span className="text-neutral-400 font-mono">Total Rows: {allOrders.length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FIFO Queue Visualizer Strip (LinkedList<Order>)                */}
      {/* ------------------------------------------------------------- */}
      <div className="px-5 py-2.5 bg-[#EBF1F8] border-t border-b border-neutral-300">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center space-x-2 text-xs font-bold text-[#21325E]">
            <span className="inline-block w-2 h-2 rounded-full bg-blue-600" />
            <span>FIFO Queue Visualizer: <code className="font-mono text-blue-950">Queue&lt;Order&gt; orderQueue = new LinkedList&lt;&gt;();</code></span>
          </div>
          <span className="text-[11px] text-neutral-600">
            Head (<code className="text-blue-800 font-mono">peek()</code>) ➔ Tail (<code className="text-blue-800 font-mono">offer()</code>)
          </span>
        </div>

        <div className="flex items-center space-x-2 overflow-x-auto py-1">
          {orderQueue.length === 0 ? (
            <div className="text-xs text-neutral-500 italic py-1">
              Queue is currently empty. (<code className="font-mono">orderQueue.isEmpty() == true</code>)
            </div>
          ) : (
            orderQueue.map((ord, idx) => (
              <React.Fragment key={ord.token}>
                <div 
                  onClick={() => setSelectedToken(ord.token)}
                  className={`flex-shrink-0 px-2.5 py-1.5 rounded border text-xs cursor-pointer shadow-xs transition ${
                    idx === 0 
                      ? 'bg-blue-600 text-white border-blue-700 ring-2 ring-blue-300' 
                      : 'bg-white text-neutral-800 border-neutral-300 hover:border-blue-400'
                  }`}
                >
                  <div className="flex items-center space-x-1.5 font-mono font-bold">
                    <span>#{ord.token}</span>
                    <span className="text-[10px] font-sans font-normal opacity-80 truncate max-w-[80px]">
                      {ord.studentName}
                    </span>
                  </div>
                  <div className="text-[10px] flex items-center justify-between mt-0.5 opacity-90">
                    <span>{ord.foodName}</span>
                    <span className="ml-1 text-[9px] uppercase font-bold tracking-tight">
                      {idx === 0 ? '[HEAD]' : `#${idx + 1}`}
                    </span>
                  </div>
                </div>
                {idx < orderQueue.length - 1 && (
                  <ArrowRight className="w-3.5 h-3.5 text-neutral-400 flex-shrink-0" />
                )}
              </React.Fragment>
            ))
          )}
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* Bottom Action Bar: Call Next, Mark Ready, Mark Served         */}
      {/* ------------------------------------------------------------- */}
      <div 
        className="bg-[#E9EEF4] px-5 py-3 border-t border-neutral-300 flex flex-col sm:flex-row items-center justify-between gap-3"
        id="swing-bottom-actions-panel"
      >
        <div className="text-xs text-neutral-600 flex items-center gap-1.5">
          <span className="font-semibold text-neutral-700">Status Flow:</span>
          <span className="font-mono text-[11px] bg-white px-2 py-0.5 rounded border border-neutral-300">
            WAITING ➔ PREPARING ➔ READY ➔ SERVED
          </span>
        </div>

        <div className="flex items-center space-x-2 sm:space-x-3 w-full sm:w-auto justify-end">
          {/* Button 1: Call Next (Requirement 11) */}
          <button
            onClick={handleCallNext}
            className="flex-1 sm:flex-none px-4 py-2 bg-[#1E64C8] hover:bg-[#1853A6] active:bg-[#134388] text-white text-xs font-bold rounded shadow-sm border border-[#1853A6] transition cursor-pointer flex items-center justify-center space-x-1.5"
            id="btn-call-next"
            title="Peeks head of queue and sets status to PREPARING"
          >
            <Flame className="w-3.5 h-3.5" />
            <span>Call Next</span>
          </button>

          {/* Button 2: Mark Ready (Requirement 12) */}
          <button
            onClick={handleMarkReady}
            className="flex-1 sm:flex-none px-4 py-2 bg-[#DC8200] hover:bg-[#B86D00] active:bg-[#945700] text-white text-xs font-bold rounded shadow-sm border border-[#B86D00] transition cursor-pointer flex items-center justify-center space-x-1.5"
            id="btn-mark-ready"
            title="Sets selected order status to READY"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Mark Ready</span>
          </button>

          {/* Button 3: Mark Served (Requirement 13) */}
          <button
            onClick={handleMarkServed}
            className="flex-1 sm:flex-none px-4 py-2 bg-[#28965A] hover:bg-[#207A49] active:bg-[#186139] text-white text-xs font-bold rounded shadow-sm border border-[#207A49] transition cursor-pointer flex items-center justify-center space-x-1.5"
            id="btn-mark-served"
            title="Sets status to SERVED and polls from front of queue"
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Mark Served</span>
          </button>
        </div>
      </div>
    </div>
  );
};
