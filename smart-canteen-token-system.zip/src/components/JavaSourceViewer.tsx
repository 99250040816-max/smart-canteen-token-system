import React, { useState } from 'react';
import { JAVA_SOURCE_CODE } from '../data/javaSource';
import { Copy, Check, Download, Terminal, BookOpen, FileCode, ExternalLink } from 'lucide-react';

export const JavaSourceViewer: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'code' | 'viva'>('code');

  const handleCopy = () => {
    navigator.clipboard.writeText(JAVA_SOURCE_CODE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownload = () => {
    const blob = new Blob([JAVA_SOURCE_CODE], { type: 'text/x-java-source' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'SmartCanteenTokenSystem.java';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full max-w-5xl mx-auto bg-white border border-neutral-300 rounded-lg shadow-xl overflow-hidden font-sans flex flex-col">
      {/* Top Controls Bar */}
      <div className="bg-[#1B294D] text-white px-4 py-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-neutral-700">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-900/60 rounded border border-blue-700 text-amber-400">
            <FileCode className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-sm sm:text-base font-bold text-white font-mono">
                SmartCanteenTokenSystem.java
              </h2>
              <span className="text-[10px] bg-amber-400/20 text-amber-300 border border-amber-400/40 px-1.5 py-0.5 rounded font-mono font-semibold">
                Single-File Java Swing
              </span>
            </div>
            <p className="text-xs text-blue-200">
              Ready to compile with standard JDK (Java 8, 11, 17, 21+) — Zero external dependencies
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2 self-stretch sm:self-auto">
          <button
            onClick={handleCopy}
            className="flex-1 sm:flex-none inline-flex items-center justify-center space-x-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white text-xs font-semibold rounded shadow-xs transition cursor-pointer"
            id="copy-java-code-btn"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied to Clipboard!' : 'Copy Code'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="flex-1 sm:flex-none inline-flex items-center justify-center space-x-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white text-xs font-semibold rounded shadow-xs transition cursor-pointer"
            id="download-java-file-btn"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download .java</span>
          </button>
        </div>
      </div>

      {/* View Toggle Tabs */}
      <div className="bg-neutral-100 border-b border-neutral-200 px-4 py-2 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveSubTab('code')}
            className={`px-3 py-1 text-xs font-medium rounded transition cursor-pointer ${
              activeSubTab === 'code'
                ? 'bg-white text-[#21325E] shadow-xs font-semibold border border-neutral-300'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <FileCode className="w-3.5 h-3.5" /> Source Code View
            </span>
          </button>
          <button
            onClick={() => setActiveSubTab('viva')}
            className={`px-3 py-1 text-xs font-medium rounded transition cursor-pointer ${
              activeSubTab === 'viva'
                ? 'bg-white text-[#21325E] shadow-xs font-semibold border border-neutral-300'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5" /> B.Tech Viva &amp; Architecture Notes
            </span>
          </button>
        </div>

        <div className="hidden md:flex items-center space-x-2 text-[11px] text-neutral-500">
          <Terminal className="w-3 h-3 text-neutral-400" />
          <span><code className="font-mono bg-neutral-200 px-1 py-0.5 rounded">javac SmartCanteenTokenSystem.java</code></span>
        </div>
      </div>

      {/* Subtab 1: Code View */}
      {activeSubTab === 'code' && (
        <div className="flex flex-col">
          {/* Quick Terminal Guide Strip */}
          <div className="bg-[#282C34] text-neutral-300 px-4 py-2.5 text-xs font-mono border-b border-neutral-700 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center space-x-2">
              <span className="text-emerald-400 font-bold">$</span>
              <span>How to run on local machine:</span>
              <span className="text-amber-300 bg-neutral-800 px-2 py-0.5 rounded">javac SmartCanteenTokenSystem.java && java SmartCanteenTokenSystem</span>
            </div>
            <span className="text-[11px] text-neutral-400">Lines: 500+ | Pure Swing (JFrame)</span>
          </div>

          {/* Code Viewer Container with Line Numbers */}
          <div className="bg-[#1E1E1E] text-neutral-100 p-4 overflow-x-auto max-h-[620px] font-mono text-xs leading-relaxed select-text">
            <pre className="text-neutral-200">
              <code>{JAVA_SOURCE_CODE}</code>
            </pre>
          </div>
        </div>
      )}

      {/* Subtab 2: Project Viva Notes */}
      {activeSubTab === 'viva' && (
        <div className="p-6 bg-neutral-50 space-y-6 overflow-y-auto max-h-[650px] text-neutral-800 text-sm">
          <div>
            <h3 className="text-base font-bold text-[#21325E] flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-blue-700" />
              B.Tech 2nd Year CSE / AIML Mini Project Documentation
            </h3>
            <p className="text-xs text-neutral-600 mt-1">
              Key concepts, data structures, and Swing architecture for laboratory assessment and external viva examination.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Card 1: Data Structures */}
            <div className="p-4 bg-white border border-neutral-300 rounded shadow-xs">
              <h4 className="font-bold text-xs uppercase text-blue-900 tracking-wider mb-2">
                1. Data Structure: FIFO Queue
              </h4>
              <p className="text-xs text-neutral-600 leading-relaxed">
                The application uses Java Collections Framework: <code className="font-mono bg-blue-50 text-blue-800 px-1 py-0.5 rounded">Queue&lt;Order&gt; orderQueue = new LinkedList&lt;&gt;();</code>.
              </p>
              <ul className="mt-2 text-xs space-y-1.5 text-neutral-700 list-disc list-inside">
                <li><code className="font-mono text-blue-800">offer(Order)</code>: Enqueues a new order at the tail (O(1)).</li>
                <li><code className="font-mono text-blue-800">peek()</code>: Inspects head order without removing it for kitchen preparation (O(1)).</li>
                <li><code className="font-mono text-blue-800">poll()</code>: Dequeues completed order upon being served (O(1)).</li>
              </ul>
            </div>

            {/* Card 2: Swing Architecture */}
            <div className="p-4 bg-white border border-neutral-300 rounded shadow-xs">
              <h4 className="font-bold text-xs uppercase text-blue-900 tracking-wider mb-2">
                2. GUI Architecture &amp; EDT
              </h4>
              <p className="text-xs text-neutral-600 leading-relaxed">
                Swing components are not thread-safe. As mandated by Swing specification, the GUI must be launched on the <strong>Event Dispatch Thread (EDT)</strong>:
              </p>
              <div className="mt-2 font-mono text-[11px] bg-neutral-100 p-2 rounded text-neutral-800 border border-neutral-200">
                SwingUtilities.invokeLater(() -&gt; showLoginDialog());
              </div>
              <p className="text-xs text-neutral-600 mt-2">
                This guarantees smooth repainting and prevents race conditions.
              </p>
            </div>

            {/* Card 3: OOP Principles */}
            <div className="p-4 bg-white border border-neutral-300 rounded shadow-xs">
              <h4 className="font-bold text-xs uppercase text-blue-900 tracking-wider mb-2">
                3. OOP Principles Applied
              </h4>
              <ul className="text-xs space-y-1.5 text-neutral-700 list-disc list-inside">
                <li><strong>Inheritance:</strong> <code className="font-mono text-blue-800">SmartCanteenTokenSystem extends JFrame</code>.</li>
                <li><strong>Encapsulation:</strong> Inner static <code className="font-mono text-blue-800">Order</code> class with private fields and getter/setter methods.</li>
                <li><strong>Polymorphism:</strong> <code className="font-mono text-blue-800">ActionListener</code> interface implementations for event-driven response.</li>
              </ul>
            </div>

            {/* Card 4: JTable & Model */}
            <div className="p-4 bg-white border border-neutral-300 rounded shadow-xs">
              <h4 className="font-bold text-xs uppercase text-blue-900 tracking-wider mb-2">
                4. JTable &amp; DefaultTableModel
              </h4>
              <p className="text-xs text-neutral-600 leading-relaxed">
                Orders are displayed using a dynamic <code className="font-mono bg-blue-50 text-blue-800 px-1 py-0.5 rounded">DefaultTableModel</code> mounted inside a <code className="font-mono bg-blue-50 text-blue-800 px-1 py-0.5 rounded">JScrollPane</code>.
              </p>
              <ul className="mt-2 text-xs space-y-1 text-neutral-700 list-disc list-inside">
                <li>Row height configured to ~28px for readability.</li>
                <li>Cell editing disabled to protect transactional data.</li>
                <li>Single row selection model for precise order dispatching.</li>
              </ul>
            </div>
          </div>

          {/* Quick FAQ / Viva Questions */}
          <div className="p-4 bg-blue-50/70 border border-blue-200 rounded">
            <h4 className="font-bold text-xs uppercase text-blue-950 tracking-wider mb-2">
              Common Viva Questions &amp; Answers
            </h4>
            <div className="space-y-2.5 text-xs text-neutral-800">
              <div>
                <strong className="text-blue-950">Q: Why did you use LinkedList instead of ArrayList for the Queue?</strong>
                <p className="text-neutral-600 mt-0.5">
                  A: LinkedList implements the Queue interface and supports O(1) removal from the head via poll() and O(1) insertion at the tail via offer(), whereas removing from index 0 in an ArrayList requires O(N) element shifting.
                </p>
              </div>
              <div>
                <strong className="text-blue-950">Q: What happens when an order status changes?</strong>
                <p className="text-neutral-600 mt-0.5">
                  A: The order object is updated in memory, and the helper method <code>updateTable(Order order)</code> locates the matching row in DefaultTableModel by token number and updates the Status column dynamically.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
