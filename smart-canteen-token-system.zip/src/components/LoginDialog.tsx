import React, { useState } from 'react';
import { Lock, User, KeyRound, Coffee, HelpCircle } from 'lucide-react';

interface Props {
  onLoginSuccess: () => void;
  showSwingAlert: (title: string, message: string, type?: 'INFO' | 'ERROR' | 'WARNING') => void;
}

export const LoginDialog: React.FC<Props> = ({ onLoginSuccess, showSwingAlert }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'admin' && password === '1234') {
      onLoginSuccess();
    } else {
      showSwingAlert('Login Error', 'Invalid Username or Password!', 'ERROR');
      setPassword('');
    }
  };

  const fillDefaultCredentials = () => {
    setUsername('admin');
    setPassword('1234');
  };

  return (
    <div className="w-full flex items-center justify-center p-4">
      <div 
        className="w-full max-w-[420px] bg-[#F8FAFC] border border-neutral-300 rounded-lg shadow-xl overflow-hidden font-sans"
        id="login-window-frame"
      >
        {/* Swing JFrame Title Bar */}
        <div className="bg-[#21325E] text-white px-4 py-2.5 flex items-center justify-between select-none">
          <div className="flex items-center space-x-2">
            <Coffee className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold tracking-wider">SMART CANTEEN LOGIN</span>
          </div>
          <div className="flex items-center space-x-1.5 opacity-80">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-400/40 inline-block" />
            <span className="w-2.5 h-2.5 rounded-full bg-slate-400/40 inline-block" />
            <span className="w-2.5 h-2.5 rounded-full bg-red-400/80 inline-block" />
          </div>
        </div>

        {/* Swing JPanel Content (GridBagLayout style) */}
        <div className="p-6 bg-gradient-to-b from-white to-[#F1F5F9]">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-blue-50 border border-blue-200 text-[#21325E] mb-3 shadow-inner">
              <Lock className="w-7 h-7" />
            </div>
            <h2 className="text-lg font-bold text-[#21325E]">SMART CANTEEN LOGIN</h2>
            <p className="text-xs text-neutral-500 mt-1">
              Swing Authenticator | Default: <span className="font-mono font-semibold text-neutral-700">admin</span> / <span className="font-mono font-semibold text-neutral-700">1234</span>
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label 
                htmlFor="login-username"
                className="block text-xs font-bold text-neutral-700 mb-1 flex items-center gap-1.5"
              >
                <User className="w-3.5 h-3.5 text-neutral-500" />
                Username:
              </label>
              <input
                id="login-username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter username"
                className="w-full px-3 py-2 text-sm bg-white border border-neutral-300 rounded focus:outline-none focus:ring-2 focus:ring-[#21325E] focus:border-transparent transition"
                autoFocus
              />
            </div>

            <div>
              <label 
                htmlFor="login-password"
                className="block text-xs font-bold text-neutral-700 mb-1 flex items-center gap-1.5"
              >
                <KeyRound className="w-3.5 h-3.5 text-neutral-500" />
                Password: <span className="text-[10px] font-normal text-neutral-500">(JPasswordField)</span>
              </label>
              <input
                id="login-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full px-3 py-2 text-sm bg-white border border-neutral-300 rounded focus:outline-none focus:ring-2 focus:ring-[#21325E] focus:border-transparent transition font-mono"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                id="login-submit-button"
                className="w-full py-2.5 px-4 bg-[#21325E] hover:bg-[#1B294D] active:bg-[#15203D] text-white text-sm font-bold rounded shadow transition cursor-pointer flex items-center justify-center space-x-2"
              >
                <span>LOGIN</span>
              </button>
            </div>
          </form>

          {/* Quick Demo Helper */}
          <div className="mt-5 pt-4 border-t border-neutral-200 flex items-center justify-between text-xs">
            <button
              type="button"
              onClick={fillDefaultCredentials}
              className="text-blue-700 hover:text-blue-900 font-medium hover:underline flex items-center gap-1 cursor-pointer"
              id="fill-demo-credentials-btn"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              Auto-Fill Credentials (admin / 1234)
            </button>
            <span className="text-[11px] text-neutral-400 font-mono">JFrame (380 × 260)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
