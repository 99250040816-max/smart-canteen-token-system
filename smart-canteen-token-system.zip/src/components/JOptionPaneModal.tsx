import React, { useEffect } from 'react';
import { JOptionPaneAlert } from '../types';
import { Info, AlertTriangle, XCircle } from 'lucide-react';

interface Props {
  alert: JOptionPaneAlert | null;
  onClose: () => void;
}

export const JOptionPaneModal: React.FC<Props> = ({ alert, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === 'Escape') {
        onClose();
      }
    };
    if (alert) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [alert, onClose]);

  if (!alert) return null;

  const getIcon = () => {
    switch (alert.type) {
      case 'ERROR':
        return <XCircle className="w-10 h-10 text-red-600 flex-shrink-0" />;
      case 'WARNING':
        return <AlertTriangle className="w-10 h-10 text-amber-500 flex-shrink-0" />;
      case 'INFO':
      default:
        return <Info className="w-10 h-10 text-blue-600 flex-shrink-0" />;
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-[1px] p-4"
      role="dialog"
      aria-modal="true"
      id="swing-joptionpane-overlay"
    >
      <div 
        className="w-full max-w-md bg-[#ECE9D8] sm:bg-[#F0F2F5] border border-neutral-400 rounded shadow-2xl overflow-hidden font-sans text-neutral-800 animate-in fade-in zoom-in-95 duration-150"
        id="swing-joptionpane-dialog"
      >
        {/* Swing Window Header */}
        <div className="bg-gradient-to-r from-[#21325E] to-[#2E4782] px-3 py-1.5 flex items-center justify-between text-white select-none">
          <div className="flex items-center space-x-2 text-xs font-semibold">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block" />
            <span>{alert.title}</span>
          </div>
          <button 
            onClick={onClose}
            className="text-white/80 hover:text-white hover:bg-red-600 px-1.5 py-0.5 rounded text-xs transition"
            id="joptionpane-close-button"
            title="Close"
          >
            ✕
          </button>
        </div>

        {/* Swing Dialog Content */}
        <div className="p-6 bg-[#FAFBFD] border-b border-neutral-300">
          <div className="flex items-start space-x-4">
            {getIcon()}
            <div className="flex-1 pt-1">
              <p className="text-sm font-medium text-neutral-800 whitespace-pre-line leading-relaxed">
                {alert.message}
              </p>
            </div>
          </div>
        </div>

        {/* Swing Dialog Button Bar */}
        <div className="bg-[#E9EEF4] px-4 py-3 flex justify-center sm:justify-end space-x-3">
          <button
            onClick={onClose}
            autoFocus
            className="px-6 py-1.5 bg-[#21325E] hover:bg-[#1B294D] active:bg-[#15203D] text-white text-xs font-bold rounded shadow-sm border border-[#1B294D] transition cursor-pointer min-w-[80px]"
            id="joptionpane-ok-button"
          >
            OK
          </button>
        </div>
      </div>
    </div>
  );
};
