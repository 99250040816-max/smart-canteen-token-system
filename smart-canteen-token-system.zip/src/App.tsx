import React, { useState } from 'react';
import { LoginDialog } from './components/LoginDialog';
import { CanteenDashboard } from './components/CanteenDashboard';
import { JOptionPaneModal } from './components/JOptionPaneModal';
import { JavaSourceViewer } from './components/JavaSourceViewer';
import { JOptionPaneAlert } from './types';
import { Monitor, FileCode, Coffee, ShieldCheck, Download } from 'lucide-react';
import { JAVA_SOURCE_CODE } from './data/javaSource';

export default function App() {
  // Navigation tabs: 'simulator' or 'code'
  const [activeTab, setActiveTab] = useState<'simulator' | 'code'>('simulator');

  // Simulator authentication state
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);

  // Global Swing JOptionPane modal state
  const [alert, setAlert] = useState<JOptionPaneAlert | null>(null);

  const showSwingAlert = (title: string, message: string, type: 'INFO' | 'ERROR' | 'WARNING' = 'INFO') => {
    setAlert({ title, message, type });
  };

  const handleDownloadJava = () => {
    const blob = new Blob([JAVA_SOURCE_CODE], { type: 'text/x-java-source' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'SmartCanteenTokenSystem.java';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#E5E9F0] text-neutral-900 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Application Bar */}
      <header className="bg-[#172033] text-white border-b border-neutral-800 shadow-md sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3">
          {/* Brand & Project Info */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-xs">
              <Coffee className="w-5 h-5 text-neutral-900" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-sm tracking-wide">Smart Canteen Token System</span>
                <span className="text-[10px] bg-blue-500/20 text-blue-300 border border-blue-400/30 px-1.5 py-0.2 rounded font-mono font-semibold">
                  Java Swing
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 hidden sm:block">
                B.Tech 2nd Year CSE / AIML Mini Project • Pure Java JFrame Single File
              </p>
            </div>
          </div>

          {/* Mode Switcher Tabs & Direct Download */}
          <div className="flex items-center space-x-2">
            <div className="bg-[#0F172A] p-1 rounded-lg border border-neutral-700 flex items-center space-x-1">
              <button
                onClick={() => setActiveTab('simulator')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
                  activeTab === 'simulator'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
                }`}
                id="tab-simulator-btn"
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>Interactive Desktop Preview</span>
              </button>

              <button
                onClick={() => setActiveTab('code')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
                  activeTab === 'code'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
                }`}
                id="tab-code-btn"
              >
                <FileCode className="w-3.5 h-3.5" />
                <span>SmartCanteenTokenSystem.java</span>
              </button>
            </div>

            <button
              onClick={handleDownloadJava}
              className="hidden lg:inline-flex items-center space-x-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-md shadow-xs transition cursor-pointer"
              title="Download SmartCanteenTokenSystem.java"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .java</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col justify-center items-center">
        {activeTab === 'simulator' ? (
          <div className="w-full flex flex-col items-center">
            {/* Desktop Environment Hint */}
            <div className="mb-4 text-center max-w-2xl">
              <div className="inline-flex items-center space-x-2 text-xs text-neutral-600 bg-neutral-200/80 px-3 py-1 rounded-full border border-neutral-300 shadow-2xs">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>
                  {isLoggedIn 
                    ? 'Main JFrame Active: 900 × 550 Canteen Dashboard with JTable & FIFO Queue'
                    : 'Swing Login Dialog Active (Username: "admin", Password: "1234")'}
                </span>
              </div>
            </div>

            {/* Render Login Window or Main Dashboard */}
            {!isLoggedIn ? (
              <LoginDialog
                onLoginSuccess={() => {
                  setIsLoggedIn(true);
                  showSwingAlert(
                    'Login Success',
                    'Welcome, admin! Loading Smart Canteen Token System dashboard...',
                    'INFO'
                  );
                }}
                showSwingAlert={showSwingAlert}
              />
            ) : (
              <CanteenDashboard
                onLogout={() => {
                  setIsLoggedIn(false);
                  showSwingAlert(
                    'Logged Out',
                    'You have safely closed the session. Returned to Login screen.',
                    'INFO'
                  );
                }}
                showSwingAlert={showSwingAlert}
              />
            )}
          </div>
        ) : (
          <div className="w-full">
            <JavaSourceViewer />
          </div>
        )}
      </main>

      {/* Global Swing JOptionPane Alert Component */}
      <JOptionPaneModal
        alert={alert}
        onClose={() => setAlert(null)}
      />

      {/* Footer */}
      <footer className="bg-neutral-200 border-t border-neutral-300 py-3 text-center text-xs text-neutral-600">
        <p>
          Smart Canteen Token System • Built with pure Java Swing (JFrame, JPanel, JTable, DefaultTableModel, FIFO Queue) • Ready for College Lab &amp; Viva
        </p>
      </footer>
    </div>
  );
}
